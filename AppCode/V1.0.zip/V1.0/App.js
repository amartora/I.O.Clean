import React, {useEffect} from 'react';
import Navigator from './routes/homeStack';
//import MQTTConnection from './MQTTConnection';

export default function App() {
  
  return (
    <Navigator />
  );
}
