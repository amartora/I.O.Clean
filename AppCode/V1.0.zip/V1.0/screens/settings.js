import React from 'react';
import { globalStyles } from '../styles/globalstyles';
import { View, Text, Button } from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';

export default function Moreinfo({ navigation }) {
    const pressHandler = () => {
        navigation.navigate('IOClean_Home')
    }
    return (
        <View style={{flex: 1}}>
            <LinearGradient
                colors={['#6DD5FA', '#CCFFFF', '#6DD5FA']}
                style={{flex: 1, paddingVertical: 50}}
            >
                <Text style={globalStyles.setText}> I.O.Clean is a smart dashboard that allows you to monitor your living space or property from your Smartphone!</Text>
                <Text> </Text>
                <Text style={globalStyles.setText}> Created by Alex Martorano, Edward Gaskin, and Jonathan Banks</Text>
                <Text> </Text>
                <Text style={{textAlign: 'center',}}>If you need assistance with the app, please contact our Dev Team via email. Or visit our website at ioclean.xyz</Text>
                <Text> </Text>
                <Text style={{textAlign: 'center',}}>Thank you for choosing I.O.Clean</Text>
            </LinearGradient>
        </View>
    )
}