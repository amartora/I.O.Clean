import React, { useState, useEffect } from 'react';
import { View, Image, TouchableOpacity, Text, ActivityIndicator, FlatList } from 'react-native';
import { globalStyles } from '../styles/globalstyles';
import {LinearGradient} from 'expo-linear-gradient';

export default function Home({ navigation }) {
    const [UVCStat, setUVCStat] = useState('Cleaning...');
    const [temp, setTemp] = useState('50');
    const [percent, setPercent] = useState('72');


    //screen management
    const sendToDev1 = () => {
        navigation.navigate('Device1')
    }
    const sendToDev2 = () => {
        navigation.navigate('Device2')
    }
    const sendToDev3 = () => {
        navigation.navigate('Device3')
    }
    const sendToDev4 = () => {
        navigation.navigate('Device4')
    }
    const sendToSett = () => {
        navigation.navigate('Settings')
    }
    //end screen management
    


    //db authentication
    const [isLoading, setLoading] = useState(true);
    const [data, setData] = useState([]);
    const [isLoading2, setLoading2] = useState(true);
    
    //connect to server.js using node server, must be IP address of system running node server ex: my laptop
    useEffect(() => {
        fetch('http://192.168.1.24:3306/fridge')
          .then((response) => response.json())
          .then((json) => setData(json))
          .catch((error) => console.error(error))
          .finally(() => setLoading(false));
      }, []);

      /*async function dbPull(){
          const response = await fetch('http://192.168.1.24:3306/soap');
          const data = await response.json();
      }
      dbPull().then(data => {
            setLoading(false);
            setData(data);
      });*/
      
      //soap
      /*useEffect(() => {
        await fetch('http://192.168.1.24:3306/soap')
          .then((response) => response.json())
          .then((json) => setPercent(json))
          .catch((error) => console.error(error))
          .finally(() => setLoading2(false));
      }, []);*/
    //end db

    
    return (
         
        <View  style={{flex: 1 }}>
        <LinearGradient
                colors={['#6DD5FA', '#CCFFFF', '#6DD5FA']}
                style={{flex: 1, alignItems: 'center'}}
            >
            <Image 
                style={globalStyles.backgroundImage}
                source={require('../assets/ioclean.png')}
            />
            <View style={{flex: 1, paddingVertical: 65,}}>
            <View style={globalStyles.butCont}>
            <TouchableOpacity onPress={sendToDev1}>
                <View style={globalStyles.button}>
                <Text style={globalStyles.text}>Fridge</Text>
                {isLoading ? <ActivityIndicator/> : (
                        
                        <FlatList
                            data={data}
                            keyExtractor={({ id }, index) => id}
                            renderItem={({ item }) => (
                            <Text style={globalStyles.text4}> 34.30°F  65.43% </Text> )}
                        />
                    )}
                    
                     
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={sendToDev2}>
                <View style={globalStyles.button}>
                    <Text style={globalStyles.text}>Soap Dispenser</Text>
                    {isLoading ? <ActivityIndicator/> : (
                    <Text style={globalStyles.text4}>{percent}% Capacity</Text>
                    )}
                </View>
            </TouchableOpacity>
            </View>

            <View style={globalStyles.butCont}> 
            <TouchableOpacity onPress={sendToDev3}>
                <View style={globalStyles.button}>
                    <Text style={globalStyles.text}>UV-C Robot</Text>
                    <Text style={globalStyles.text4}>{UVCStat}</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={sendToDev4}>
                <View style={globalStyles.button}>
                   
                    <Text style={globalStyles.text3}>+</Text>
                </View>
            </TouchableOpacity>
            </View>
            </View>
            <View style={globalStyles.refresh}>
            <TouchableOpacity >
                    <Text style={globalStyles.text2}>Refresh</Text>
                </TouchableOpacity>
            </View>
            <View style={globalStyles.settings}>
                
                <TouchableOpacity onPress={sendToSett}>
                    <Text style={globalStyles.text2}>About Us</Text>
                </TouchableOpacity>
                
            </View>
            </LinearGradient>
        </View>
    );
}