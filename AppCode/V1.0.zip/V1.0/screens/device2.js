import React, { useState, useEffect } from 'react';
import { globalStyles } from '../styles/globalstyles';
import { View, Text, ScrollView, FlatList, ActivityIndicator, Image} from 'react-native';
import {ProgressCircle} from 'react-native-svg-charts';
import {LinearGradient} from 'expo-linear-gradient';
import Hyperlink from 'react-native-hyperlink';


export default function Moreinfo() {
    const [days, setDays] = useState('0');
    const [data, setData] = useState('');
    const [percent, setPercent] = useState('75');
    const [isLoading, setLoading] = useState('true');
    //const [ minutes, setMinutes] = useState('0');
  
    //connect to SoapServer.js using node.js , must be IP address of system running node server ex: my laptop
  useEffect(() => {
    const url = 'http://196.168.1.24:3306/soap';
    fetch(url)
    .then(res => res.json())
    .then(json => setData(json))
    .catch(error => console.log(error))
    .finally(setLoading(false))
    }, []);
  //end db

 /* async function dbPull(){
    const response = await fetch('http://192.168.1.24:3306/soap');
    const data = await response.json();
}
  dbPull().then(data => {
      setLoading(false);
      setData(data);
});*/

       
    return (        
        <View style={{flex: 1}}>
          <LinearGradient 
          colors={['#6DD5FA', '#CCFFFF', '#6DD5FA']}
          style={globalStyles.banBack}>
            <ScrollView>
              <Text style={globalStyles.setText}>Soap Dispenser</Text>
              <View style={{flex: 1}}>
                  <Text style={globalStyles.log}>LOG: </Text>
                  {isLoading ? <ActivityIndicator/> : (
                    <FlatList
                        data={data}
                        keyExtractor={(id, index) => id}
                        renderItem={({ item }) => (
                        <Text style={globalStyles.text}> {item.percentage}%, {item.time}</Text>)}
                        
                    />
                    )}
                  </View>
              <ProgressCircle
                style={{height: 150, paddingTop: 95}}
                progress={0.75}
                progressColor={'rgb(0, 51, 153)'}
                strokeWidth={25}
                
              />
              <Text style={globalStyles.soap}>{percent}%</Text>
              
                  <View style={{flex: 1, padding: 100}}>
                    <Text style={globalStyles.setText}>Buy More:</Text>
                    <View style={{flexDirection: 'row', paddingVertical:20}}>
                    <Image 
                      style={{
                        width: 150, 
                        height: 175,
                        alignItems: 'center',
                        justifyContent: 'center',
                        paddingHorizontal: 15,
                        
                      }}
                      source={require('../assets/duracell2032.png')}
                    />
                    <View style={{flexDirection: 'column'}}>
                    <Text style={globalStyles.log}>      $10.34</Text>
                   
                     
                    </View>
                  </View>
                  <View style={{flexDirection: 'row'}}>
                    <Image 
                      style={{
                        width: 175, 
                        height: 150,
                        alignItems: 'center',
                        justifyContent: 'center',
                        paddingHorizontal: 10,
                      }}
                      source={require('../assets/meyers.png')}
                    />
                    <View style={{flexDirection: 'column'}}>
                    <Text style={globalStyles.log}>      $11.64</Text>
                   
                     
                    </View>
                  </View>
                    
                </View>
            </ScrollView>
          </LinearGradient>
        </View>       
  )
}