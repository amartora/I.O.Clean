import React, { useState, useEffect } from 'react';
import { globalStyles } from '../styles/globalstyles';
import { View, Text, ScrollView, FlatList, ActivityIndicator, Image, Button } from 'react-native';
import {LineChart, Grid} from 'react-native-svg-charts';
import {LinearGradient} from 'expo-linear-gradient';
import Hyperlink from 'react-native-hyperlink';

export default function Moreinfo(props){
  //db authentication
  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [temp, setTemp] = useState([]);
  const [humid, setHumid] = useState([]);
 
 //test data
  const temp2 = [38.1, 40.2, 39.9, 34.30];
  const humid2 = [62, 61, 61, 59];
  const AM = 'https://www.amazon.com/Duracell-CopperTop-Batteries-all-purpose-household/dp/B0035LCFNQ/ref=sr_1_1_sspa?dchild=1&keywords=duracell+AA+batteries&qid=1618976837&sr=8-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUExQ1lXNk1LMkwwV1kzJmVuY3J5cHRlZElkPUEwNjY0MzA4M1ZXRUZSOEJXVlJIOSZlbmNyeXB0ZWRBZElkPUEwOTY2MDc5VFhTNjA0SzQxRDBEJndpZGdldE5hbWU9c3BfYXRmJmFjdGlvbj1jbGlja1JlZGlyZWN0JmRvTm90TG9nQ2xpY2s9dHJ1ZQ==';
  
  //connect to server.js using node server, must be IP address of system running node server ex: my laptop
  useEffect(() => {
    const url = 'http://192.168.1.24:3306/fridge';
    fetch(url)
    .then(res => res.json())
    .then(json => setData(json))
    .catch(error => console.log(error))
    .finally(setLoading(false))
    }, []);
  //end db
    
    return (
        
        <View style={{flex: 1}}>
          <LinearGradient
            colors={['#6DD5FA', '#CCFFFF', '#6DD5FA']}
            style={globalStyles.banBack}
            >
        
            <View style={{paddingTop: 20,}}>
                <Text style={globalStyles.setText}>Refrigerator Sensor</Text>
            </View>
            <View style={{flex: 1}}>
                  <Text style={globalStyles.log}>LOG: </Text>
                  {isLoading ? <ActivityIndicator/> : (
                    <FlatList
                        data={data}
                        keyExtractor={(id, index) => id}
                        renderItem={({ item }) => (
                        <Text style={globalStyles.text}> {item.temp} °F, {item.humid}, {item.time}</Text>)}
                        
                    />
                    )}
                  </View>
                <ScrollView>
                <View style={{ paddingTop: 10, paddingHorizontal: 35,}} >
               
                <Text>Temperature Sensor:</Text>
                        <LineChart
                          style={{height: 200}}
                          data={temp2}
                          svg={{ stroke: 'rgb(134, 65, 244)'}}
                          contentInset={{top: 20, bottom:20}}
                        >
                          <Grid />
                        </LineChart> 
                        <Text>Humidity Sensor:</Text>
                        <LineChart
                          style={{height: 200}}
                          data={humid2}
                          svg={{ stroke: 'rgb(134, 65, 244)'}}
                          contentInset={{top: 20, bottom:20}}
                        >
                          <Grid />
                        </LineChart>   

                </View>
                  <View style={{flex: 1, padding: 10}}>
                    <Text style={globalStyles.setText}>Buy More:</Text>
                    <View style={{flexDirection: 'row'}}>
                    <Image 
                      style={globalStyles.affiliate}
                      source={require('../assets/duracell2032.png')}
                    />
                    <View style={{flexDirection: 'column'}}>
                    <Text style={globalStyles.log}>      $17.99</Text>
                    <Hyperlink onPress={AM}>
                      <Text>      Order Now!</Text>
                    </Hyperlink>
                     
                    </View>
                    </View>
                    
                  </View>
                </ScrollView>
            
            
            </LinearGradient>  
        </View>
        
    )}
  