import { StyleSheet } from 'react-native';

export const globalStyles = StyleSheet.create({
    affiliate:{
      width: 150, 
      height: 175,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 10,
    },
      container: {
      backgroundColor: 'lightgray',
      alignContent: 'center',
      justifyContent: 'center',
      flex: 1,
      
    },
    backgroundImage: {
      width: '100%', 
      height: '15%',
      alignItems: 'center',
      justifyContent: 'center',
      
      
    },
    butCont: {
      flexDirection: 'row', 
      justifyContent: 'center',
      alignItems: 'center',
      
      
    },
    banBack: {
      flex: 1,
      
      paddingVertical: 5,
    },
    banner: {
      width: '90%',
      height: '98%',
      paddingVertical: 20,
      
      flex: 1,
      margin: 20,
      borderRadius: 15,
    },
    button: {      
      width: 150,
      height: 150,
      paddingVertical: 20,
      borderRadius: 45,
      backgroundColor: 'white',
      margin: 10,
    },
    dataFont: {
      fontSize: 15,
      color: 'black',
      textAlign: 'center',
      
      
    },
    dev: {
      backgroundColor: 'lightgray',
      alignContent: 'center',
      justifyContent: 'center',
      flex: 1,
    },
    settings: {
      width: 317,
      height: 75,
      paddingVertical: 5,
      borderRadius: 15,
      backgroundColor: 'white',
      margin: 30,
      justifyContent: 'center',

    },
    text: {
      fontSize: 18,
      color: '#757e80',
      textAlign: 'center',
      fontWeight: 'bold', 
      paddingHorizontal: 25,
      paddingVertical: 15,
      
    },
    text2: {
      fontSize: 20,
      color: '#757e80',
      textAlign: 'center',
      fontWeight: 'bold', 
      
      paddingVertical: 5,
      
    },
    text3: {
      fontSize: 45,
      color: '#757e80',
      textAlign: 'center',
      fontWeight: 'bold', 
      paddingVertical: 25,
           
      
    },
    text4: {
      fontSize: 15,
      color: '#757e80',
      textAlign: 'center',
      fontWeight: 'bold', 
      paddingHorizontal: 25,
      paddingBottom:20,
    },
    setText :{
      fontSize: 24,
      color: 'black',
      textAlign: 'center',
      fontWeight: 'bold',
    },
    save: {
      fontSize: 24,
      color: 'dodgerblue',
      textAlign: 'center',
      paddingVertical: 20,
      
    },
    preferences: {
      fontSize: 24,
      color: 'black',
      textAlign: 'center',
      paddingVertical: 20,
    },
    log:{
      fontSize: 20,
      color: 'black',
    },
    refresh:{
      width: 317,
      height: 68,
      paddingVertical: 20,
      borderRadius: 15,
      backgroundColor: 'white',
      margin: 30,
      justifyContent: 'center',
    },
    soap: {
      fontSize: 35,
      color: 'black',
      textAlign: 'center',
      fontWeight: 'bold',
    }

  });