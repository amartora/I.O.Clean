const mysql = require('mysql');
const express = require('express');
const bodyParser = require('body-parser');


//db authentication
const connection = mysql.createPool({
    host: 'ioclean.xyz',
    port: '3306',
    user: 'cleanadmin',
    password: 'cleanpassword',
    database: 'IoT',
    port: '3306',
    insecureAuth: 'true'
    
});
const app = express();

app.get('/fridge', function (req, res){
    connection.getConnection(function (err, connection) {

    connection.query('SELECT * from fridge', function (error, results, fields) {
        if (error) throw error;
        res.send(results);
    });
    });
    
});

//brute force data input into app (internal)
app.listen(3306, () => {
    console.log('goto http://localhost:3306/fridge');
    
});
