import React from 'react';
import { globalStyles } from '../styles/globalstyles';
import { View, Text, Button } from 'react-native';

export default function Moreinfo({ navigation }) {
    const pressHandler = () => {
        navigation.navigate('IOClean_Home')
    }
    return (
        <View style={{justifyContent: 'flex-start', alignItems: "center", paddingVertical: 50, paddingHorizontal: 35,}}>
            <Text style={globalStyles.setText}> I.O. Clean is a smart dashboard that allows you to monitor your living space or property from your Smartphone!</Text>
            <Text> </Text>
            <Text style={globalStyles.setText}> Created by Alex Martorano, Edward Gaskin, and Jonathan Banks</Text>
            <Text> </Text>
            <Text style={{textAlign: 'center',}}>If you need assistance with the app, please contact our Dev Team via email. Or visit our website at ioclean.xyz</Text>
            <Text> </Text>
            <Text style={{textAlign: 'center',}}>Thank you for choosing I.O.Clean</Text>
        </View>
    )
}