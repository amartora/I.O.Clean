import React, { useState } from 'react';
import { globalStyles } from '../styles/globalstyles';
import { View, Text, ScrollView, TouchableOpacity, TextInput } from 'react-native';



export default function Moreinfo() {
    const [days, setDays] = useState('0');
    const [inbound, setInbound] = useState('Please Refresh');
    const [ minutes, setMinutes] = useState('0');

    const getDataUsingGet = () => {
    //GET request
    fetch('http://ioclean.xyz:45777/UVC', {
      method: 'GET',
      //Request Type
    })
      .then((response) => response.json())
      //If response is in json then in success
      .then((responseJson) => {
        //Success
        setInbound(responseJson);
        alert(JSON.stringify(responseJson));
        console.log(responseJson);
      })
      //If response is not in json then in error
      .catch((error) => {
        //Error
        alert(JSON.stringify(error));
        console.error(error);
      });
  };

  const getDataUsingPost = () => {
    //POST json
    var dataToSend = {days};
    //making data to send on server
    var formBody = [];
    for (var key in dataToSend) {
      var encodedKey = encodeURIComponent(key);
      var encodedValue = encodeURIComponent(dataToSend[key]);
      formBody.push(encodedValue);
    }
    formBody = formBody.join('&');//encoded body
    
    //POST request
    fetch('http://ioclean.xyz:45777/UVC', {
      method: 'POST', //Request Type
      body: formBody, //post body
      headers: {
        //Header Definition
        'Content-Type': 
          'application/x-www-form-urlencoded;charset=UTF-8',
      },
    })
      .then((response) => response.json())
      //If response is in json then in success
      .then((responseJson) => {
        alert(JSON.stringify(responseJson));
        console.log(responseJson);
      })
      //If response is not in json then in error
      .catch((error) => {
        alert(JSON.stringify(error));
        console.error(error);
      });
  };

    
    
        
    return (
        
        <View style={globalStyles.banBack}>
          <ScrollView>
            <View style={{paddingVertical: 20,}}>
                <Text style={globalStyles.setText}> </Text>
            </View>
            <View style={{flex: 1, backgroundColor: 'lightgray',}}>
                

            </View>
            </ScrollView>
        </View>
        
    )
    }