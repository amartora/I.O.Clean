import React from 'react';
import { View, ImageBackground, TouchableOpacity, Text } from 'react-native';
import { globalStyles } from '../styles/globalstyles';

export default function Home({ navigation }) {
    const sendToDev1 = () => {
        navigation.navigate('Device1')
    }
    const sendToDev2 = () => {
        navigation.navigate('Device2')
    }
    const sendToDev3 = () => {
        navigation.navigate('Device3')
    }
    const sendToDev4 = () => {
        navigation.navigate('Device4')
    }
    const sendToSett = () => {
        navigation.navigate('Settings')
    }
    
    return (
        <ImageBackground style={globalStyles.backgroundImage} source={require('../assets/ioclean.png')}>    
            <View style={{flex: 1, flexDirection: 'flex-end', paddingVertical: 225,}}>
            <View style={globalStyles.butCont}>
            <TouchableOpacity onPress={sendToDev1}>
                <View style={globalStyles.button}>
                    <Text style={globalStyles.text}>Refridgerator Sensor</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={sendToDev2}>
                <View style={globalStyles.button}>
                    <Text style={globalStyles.text}>Soap Dispenser</Text>
                </View>
            </TouchableOpacity>
            </View>

            <View style={globalStyles.butCont}> 
            <TouchableOpacity onPress={sendToDev3}>
                <View style={globalStyles.button}>
                    <Text style={globalStyles.text}>UV-C Robot</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={sendToDev4}>
                <View style={globalStyles.button}>
                    <Text style={globalStyles.text}> </Text>
                </View>
            </TouchableOpacity>
            </View>
            </View>
            <View style={globalStyles.settings}>
                <TouchableOpacity onPress={sendToSett}>
                    <Text style={globalStyles.text2}>Settings</Text>
                </TouchableOpacity>
                
            </View>
            
        </ImageBackground>
    );
}