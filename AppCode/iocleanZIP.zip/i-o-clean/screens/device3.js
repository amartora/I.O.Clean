import React, { useState } from 'react';
import { globalStyles } from '../styles/globalstyles';
import { View, Text, ScrollView, TouchableOpacity, TextInput } from 'react-native';



export default function Moreinfo() {
    const [active, setActive] = useState('no');
    const [inbound, setInbound] = useState('Please Refresh');
    const [square, setsetSquare] = useState('0');

    const getDataUsingGet = () => {
    //GET request
    fetch('http://ioclean.xyz:45777/UVC', {
      method: 'GET',
      //Request Type
    })
      .then((response) => response.json())
      //If response is in json then in success
      .then((responseJson) => {
        //Success
        setInbound(responseJson);
        alert(JSON.stringify(responseJson));
        console.log(responseJson);
      })
      //If response is not in json then in error
      .catch((error) => {
        //Error
        alert(JSON.stringify(error));
        console.error(error);
      });
  };

  const getDataUsingPost = () => {
    //POST json
    var dataToSend = {active} + ' , ' + {square};
    //making data to send on server
    var formBody = [];
    for (var key in dataToSend) {
      var encodedKey = encodeURIComponent(key);
      var encodedValue = encodeURIComponent(dataToSend[key]);
      formBody.push(encodedValue);
    }
    formBody = formBody.join('&');//encoded body
    
    //POST request
    fetch('http://ioclean.xyz:45777/UVC', {
      method: 'POST', //Request Type
      body: formBody, //post body
      headers: {
        //Header Definition
        'Content-Type': 
          'application/x-www-form-urlencoded;charset=UTF-8',
      },
    })
      .then((response) => response.json())
      //If response is in json then in success
      .then((responseJson) => {
        alert(JSON.stringify(responseJson));
        console.log(responseJson);
      })
      //If response is not in json then in error
      .catch((error) => {
        alert(JSON.stringify(error));
        console.error(error);
      });
  };

    
    
        
    return (
        
        <View style={globalStyles.banBack}>
          <ScrollView>
            <View style={{paddingVertical: 20,}}>
                <Text style={globalStyles.setText}>UV-C Robot</Text>
            </View>
            <View style={{flex: 1, backgroundColor: 'lightgray',}}>
                <View style={{ paddingVertical: 35, paddingHorizontal: 35,}} >
                    
                    <TouchableOpacity
                        
                        onPress={getDataUsingGet}>
                        <Text style={globalStyles.log}>
                        LOG:
                        </Text>
                        <Text>{inbound} </Text>
                    </TouchableOpacity>
                </View>
                
            </View>
            <View style={{flex: 0.5, backgroundColor: 'lightgray', paddingVertical: 100,}}> 
                <Text style={globalStyles.preferences}> -------- Device Preferences -------- </Text>
                <Text style={globalStyles.dataFont}> Activate? (yes/no): </Text>
                <TextInput
                    style={globalStyles.dataFont}
                    onChangeText={text => setActive(text)}
                    value={active}
                    placeholder='Enter Message To Send'
                />
                <Text style={globalStyles.dataFont}> Table Dimensions (sq. ft.): </Text>
                <TextInput
                    style={globalStyles.dataFont}
                    onChangeText={text => setSquare(text)}
                    value={square}
                    placeholder='Enter Message To Send'
                />
                <TouchableOpacity
                    style={globalStyles.setText}
                    onPress={getDataUsingPost}>
                    <Text style={globalStyles.save}>
                    START
                    </Text>
                </TouchableOpacity>

            </View>
            </ScrollView>
        </View>
        
    )
    }