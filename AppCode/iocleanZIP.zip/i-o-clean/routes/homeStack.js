import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import Home from '../screens/home';
import Device1 from '../screens/device1';
import Device2 from '../screens/device2';
import Device3 from '../screens/device3';
import Device4 from '../screens/device4';
import Settings from '../screens/settings';


const screens = {
    IOClean_Home : {
        screen : Home
    },
    Device1 : {
        screen : Device1
    },
    Device2 : {
        screen : Device2
    },
    Device3 : {
        screen : Device3
    },
    Device4 : {
        screen : Device4
    },
    Settings : {
        screen : Settings
    },
}
const HomeStack = createStackNavigator(screens);

export default createAppContainer(HomeStack);